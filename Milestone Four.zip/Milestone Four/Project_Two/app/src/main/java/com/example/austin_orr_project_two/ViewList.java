package com.example.austin_orr_project_two;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewList extends AppCompatActivity {

    //Assigns appropriate variables
    Database mDatabaseHelper;
    Button btnAdd, btnViewData, btnLog;
    EditText editText;

    List list;

    String newEntry = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        editText = (EditText) findViewById(R.id.editText);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnViewData = (Button) findViewById(R.id.btnView);
        btnLog = (Button) findViewById(R.id.btnLogOut);
        mDatabaseHelper = new Database(this);
        list = new List();
    }

    //Class to add new entry is activated when add button is pressed
    public void add(View view) {
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Takes entry form text field
                newEntry = editText.getText().toString();

                //Confirms text field is not void
                if (newEntry.matches("")) {
                    toastMessage("You must put something in the text field!");
                }

                //Adds new entry if text field is not void
                else {
                    AddData(newEntry);
                    editText.setText("");
                }
            }

        });
    }

    //Class to display list activates once view list button is pressed
    public void display(View view){
        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), List.class);
                startActivity(intent);
            }

        });
    }

    //Class to add new data entries
    public void AddData(String newEntry) {
        //Confirms adding new entry is successful in the database

        mDatabaseHelper.addData(newEntry);

        boolean insertData = mDatabaseHelper.addData(newEntry);

        //Confirms if adding data was successful
        if (insertData = true) {
            toastMessage(newEntry + " Successfully Inserted!");
        }
        else {
            toastMessage("Something went wrong");
        }
    }

    public void LogOut(View view){
        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                toastMessage("Log Out Successful");
            }
        });
    }

    /**
     * customizable toast
     * @param message
     */
    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}