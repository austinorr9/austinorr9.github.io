package com.example.austin_orr_project_two;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //Assign database
    Database mDatabaseHelper;

    //Assigns different aspects of the layout
    Button signIn;
    Button newUser;
    EditText editUser;
    EditText editPwd;

    //Assigns variables
    public String user = "";
    public String pwd = "";
    boolean insert = false;

    //Assigns Lists
    ArrayList<String> username;
    ArrayList<String> password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Sets up everything once app is started
        signIn = (Button) findViewById(R.id.buttonSignIn);
        newUser = (Button) findViewById(R.id.buttonNewUser);
        editUser = (EditText) findViewById(R.id.textUsername);
        editPwd = (EditText) findViewById(R.id.textPassword);
        username = new ArrayList<String>();
        password = new ArrayList<String>();
        mDatabaseHelper = new Database(this);

        //Debug adds a default data
        insert = mDatabaseHelper.addData("hello");

        //Confirms default data has been added to database
        if (insert == true) {
            toastMessage("Data was loaded.");
        }
        else if (insert == false) {
            toastMessage("Data was not loaded.");
        }

        //Adds admin credentials
        username.add("admin");
        password.add("123");
    }


    //Class for adding new user to the app is activated if newUser button is pressed
    public void NewUser(View view) {
        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Takes username and password from the text fields
                user = editUser.getText().toString();
                pwd = editPwd.getText().toString();

                //Confirms that both Strings from text fields are not void
                if (user.matches("") && pwd.matches("")) {
                    toastMessage("You must enter a name.");
                    editPwd.setText("");
                }
                //Confirms that both strings do not exist already
                else if (username.contains(user) && password.contains(pwd)) {
                    toastMessage("User already exists.");
                    editPwd.setText("");
                }

                //If both strings trip any conditions above, the new user is added
                else {
                    // Debug
                    //Toast.makeText(getApplicationContext(), "New User added successfully.", Toast.LENGTH_LONG).show();

                    username.add(user);
                    password.add(pwd);
                    toastMessage("New User added username: " + user + " password: " + pwd);
                    editPwd.setText("");
                }
            }
        });
    }

    //Class for signing in is activated when sign in button is pressed
    public void SignIn(View view) {
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Takes username and password from text fields
                user = editUser.getText().toString();
                pwd = editPwd.getText().toString();

                //Confirms if the credentials exist
                if (username.contains(user) && password.contains(pwd)) {
                    toastMessage("Log in successful.");
                    editPwd.setText("");
                    ViewList();
                }

                //Confirms if the text fields are not void
                else if(user.matches("") && pwd.matches("")) {
                    toastMessage("Enter a username and password.");
                    editPwd.setText("");
                }

                //If above conditons are not tripped then the user does not exist
                else {
                    toastMessage("Invalid Log in.");
                }
            }
        });
    }

    //Launches ViewList activity
    public void ViewList(){
        Intent intent = new Intent(getApplicationContext(), ViewList.class);
        startActivity(intent);
    }

    //Class that handles toast messages
    private void toastMessage(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
    }

}